﻿using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows;

[assembly : AssemblyTitle("MisakaTranslator_WPF")]
[assembly : AssemblyDescription("")]
[assembly : AssemblyConfiguration("")]
[assembly : AssemblyCompany("")]
[assembly : AssemblyProduct("MisakaTranslator_WPF")]
[assembly : AssemblyCopyright("Copyright © MisakaTranslator")]
[assembly : AssemblyTrademark("")]
[assembly : AssemblyCulture("")]
[assembly : ComVisible(false)]
[assembly : ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly : AssemblyVersion("2.7.0.0")]
[assembly : AssemblyFileVersion("2.7.0.0")]